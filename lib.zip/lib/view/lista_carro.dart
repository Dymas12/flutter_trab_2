import 'package:flutter/material.dart';
import '../model/carro.dart';


class ListaCarro extends StatefulWidget {
  @override
  State<ListaCarro> createState() => _HomeState();
}

class _HomeState extends State<ListaCarro> {
  final List<Carro> carros = [];
  TextEditingController _placaController = TextEditingController();
  TextEditingController _corController = TextEditingController();
  TextEditingController _anoController = TextEditingController();

  _inserir() {
    setState(() {
      carros.insert(
          0,
          Carro(_placaController.text, _corController.text, int.parse(_anoController.text)));
    });
  }

  _limparFormulario() {
    _placaController.text = "";
    _corController.text = "";
    _anoController.text = "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lista de Carros"),
        centerTitle: true,
        backgroundColor: Colors.blue,
//backgroundColor: Colors.brown,
        actions: [
          IconButton(
            onPressed: _limparFormulario,
            icon: Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              controller: _placaController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Placa',
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              controller: _corController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Cor',
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              keyboardType: TextInputType.number,
              controller: _anoController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Ano',
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              _inserir();
              _limparFormulario();
            },
            child: const Text("Inserir"),
            style: ElevatedButton.styleFrom(
              primary: Theme.of(context).primaryColor,
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8.0),
              itemCount: carros.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  height: 80,
                  margin: EdgeInsets.all(2.0),
                  color: Colors.blue,
                  child: Center(
                    child: Text(
                      "${carros[index]}",
                      style: const TextStyle(fontSize: 15),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
